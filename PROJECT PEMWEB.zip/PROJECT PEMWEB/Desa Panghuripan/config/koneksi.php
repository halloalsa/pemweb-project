<?php

$host = "localhost";
$user = "root";
$pass = "";
$database = "data_desa_panghuripan";

$koneksi = mysqli_connect($host, $user, $pass, $database) or die("koneksi gagal");