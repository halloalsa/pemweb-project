<?php
require '../config/koneksi.php';
require '../components/components.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php head('Pilih Tim') ?>
</head>

<body>
    <?php navbar() ?>
        
    <?php footer() ?>
</body>

</html>